package dao;

import config.DatabaseConnection;
import model.Student;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public void create(Student student) throws SQLException {
        String sql = "{ CALL sp_insertar_estudiante(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }";
        try (Connection connection = DatabaseConnection.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setString(1, student.getFirstName());
            statement.setString(2, student.getLastName());
            statement.setString(3, student.getMiddleName());
            statement.setString(4, student.getDocumentNumber());
            statement.setString(5, student.getAddress());
            statement.setString(6, student.getEmail());
            statement.setString(7, student.getPhone());
            statement.setDate(8, Date.valueOf(student.getBirthDate()));
            statement.setString(9, student.getGender());
            statement.setString(10, student.getDistrict());
            statement.setString(11, student.getMajor());
            statement.setInt(12, student.getCycle());
            statement.setString(13, student.getStatus());

            statement.executeUpdate();
        }
    }

    public void update(Student student) throws SQLException {
        String sql = "{ CALL sp_actualizar_estudiante(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }";
        try (Connection connection = DatabaseConnection.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, student.getId());
            statement.setString(2, student.getFirstName());
            statement.setString(3, student.getLastName());
            statement.setString(4, student.getMiddleName());
            statement.setString(5, student.getDocumentNumber());
            statement.setString(6, student.getAddress());
            statement.setString(7, student.getEmail());
            statement.setString(8, student.getPhone());
            statement.setDate(9, Date.valueOf(student.getBirthDate()));
            statement.setString(10, student.getGender());
            statement.setString(11, student.getDistrict());
            statement.setString(12, student.getMajor());
            statement.setInt(13, student.getCycle());
            statement.setString(14, student.getStatus());

            statement.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "{ CALL sp_eliminar_estudiante(?) }";
        try (Connection connection = DatabaseConnection.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public Student findById(int id) throws SQLException {
        String sql = "{ CALL sp_buscar_estudiante(?) }";
        try (Connection connection = DatabaseConnection.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    public List<Student> findAll() throws SQLException {
        String sql = "{ CALL sp_listar_estudiantes() }";
        List<Student> list = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             CallableStatement statement = connection.prepareCall(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        Student student = new Student();
        student.setId(rs.getInt("id_estudiante"));
        student.setFirstName(rs.getString("nombre"));
        student.setLastName(rs.getString("apellido_paterno"));
        student.setMiddleName(rs.getString("apellido_materno"));
        student.setDocumentNumber(rs.getString("dni"));
        student.setAddress(rs.getString("direccion"));
        student.setEmail(rs.getString("correo"));
        student.setPhone(rs.getString("telefono"));
        if (rs.getDate("fecha_nacimiento") != null) {
            student.setBirthDate(rs.getDate("fecha_nacimiento").toLocalDate());
        }
        student.setAge(rs.getInt("edad"));
        student.setGender(rs.getString("sexo"));
        student.setDistrict(rs.getString("distrito"));
        student.setMajor(rs.getString("carrera"));
        student.setCycle(rs.getInt("ciclo"));
        student.setStatus(rs.getString("estado"));
        return student;
    }
}
