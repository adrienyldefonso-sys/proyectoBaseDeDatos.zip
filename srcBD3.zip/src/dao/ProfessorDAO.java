package dao;

import config.DatabaseConnection;
import model.Professor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfessorDAO {

    public void create(Professor professor) throws SQLException {
        String sql = "INSERT INTO profesor " +
                "(nombre, apellido_paterno, apellido_materno, dni, especialidad, correo, telefono, horas_dictadas) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, professor.getFirstName());
            statement.setString(2, professor.getLastName());
            statement.setString(3, professor.getMiddleName());
            statement.setString(4, professor.getDocumentNumber());
            statement.setString(5, professor.getSpecialty());
            statement.setString(6, professor.getEmail());
            statement.setString(7, professor.getPhone());
            statement.setInt(8, professor.getTaughtHours());

            statement.executeUpdate();
        }
    }

    public void update(Professor professor) throws SQLException {
        String sql = "UPDATE profesor SET nombre=?, apellido_paterno=?, apellido_materno=?, dni=?, " +
                "especialidad=?, correo=?, telefono=?, horas_dictadas=? WHERE id_profesor=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, professor.getFirstName());
            statement.setString(2, professor.getLastName());
            statement.setString(3, professor.getMiddleName());
            statement.setString(4, professor.getDocumentNumber());
            statement.setString(5, professor.getSpecialty());
            statement.setString(6, professor.getEmail());
            statement.setString(7, professor.getPhone());
            statement.setInt(8, professor.getTaughtHours());
            statement.setInt(9, professor.getId());

            statement.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM profesor WHERE id_profesor=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public Professor findById(int id) throws SQLException {
        String sql = "SELECT * FROM profesor WHERE id_profesor=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    public List<Professor> findAll() throws SQLException {
        String sql = "SELECT * FROM profesor ORDER BY id_profesor";
        List<Professor> list = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Professor mapRow(ResultSet rs) throws SQLException {
        Professor professor = new Professor();
        professor.setId(rs.getInt("id_profesor"));
        professor.setFirstName(rs.getString("nombre"));
        professor.setLastName(rs.getString("apellido_paterno"));
        professor.setMiddleName(rs.getString("apellido_materno"));
        professor.setDocumentNumber(rs.getString("dni"));
        professor.setSpecialty(rs.getString("especialidad"));
        professor.setEmail(rs.getString("correo"));
        professor.setPhone(rs.getString("telefono"));
        professor.setTaughtHours(rs.getInt("horas_dictadas"));
        return professor;
    }
}
