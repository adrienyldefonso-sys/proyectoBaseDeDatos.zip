package dao;

import config.DatabaseConnection;
import model.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {

    public void create(Course course) throws SQLException {
        String sql = "INSERT INTO curso (nombre_curso, creditos, semestre) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, course.getName());
            statement.setInt(2, course.getCredits());
            statement.setInt(3, course.getSemester());

            statement.executeUpdate();
        }
    }

    public void update(Course course) throws SQLException {
        String sql = "UPDATE curso SET nombre_curso=?, creditos=?, semestre=? WHERE id_curso=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, course.getName());
            statement.setInt(2, course.getCredits());
            statement.setInt(3, course.getSemester());
            statement.setInt(4, course.getId());

            statement.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM curso WHERE id_curso=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public Course findById(int id) throws SQLException {
        String sql = "SELECT * FROM curso WHERE id_curso=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    public List<Course> findAll() throws SQLException {
        String sql = "SELECT * FROM curso ORDER BY id_curso";
        List<Course> list = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    private Course mapRow(ResultSet rs) throws SQLException {
        Course course = new Course();
        course.setId(rs.getInt("id_curso"));
        course.setName(rs.getString("nombre_curso"));
        course.setCredits(rs.getInt("creditos"));
        course.setSemester(rs.getInt("semestre"));
        return course;
    }
}
