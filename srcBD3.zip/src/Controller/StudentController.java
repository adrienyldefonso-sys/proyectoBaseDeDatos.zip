package Controller;

import dao.StudentDAO;
import model.Student;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

public class StudentController {

    private final StudentDAO studentDAO = new StudentDAO();

    public void showMenu(Scanner scanner) {
        Map<Integer, Runnable> actions = new HashMap<>();
        actions.put(1, () -> listStudents());
        actions.put(2, () -> createStudent(scanner));
        actions.put(3, () -> updateStudent(scanner));
        actions.put(4, () -> deleteStudent(scanner));
        actions.put(5, () -> findStudent(scanner));

        int option;
        do {
            System.out.println("\n--- GESTIONAR ESTUDIANTES ---");
            System.out.println("1. Listar estudiantes");
            System.out.println("2. Registrar estudiante");
            System.out.println("3. Actualizar estudiante");
            System.out.println("4. Eliminar estudiante");
            System.out.println("5. Buscar estudiante por ID");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            option = readInt(scanner);
            if (option == 0) {
                System.out.println("Volviendo al menú principal...");
            } else {
                Runnable action = actions.get(option);
                if (action != null) {
                    action.run();
                } else {
                    System.out.println("Opción inválida.");
                }
            }
        } while (option != 0);
    }

    private void listStudents() {
        try {
            List<Student> students = studentDAO.findAll();
            if (students.isEmpty()) {
                System.out.println("No hay estudiantes registrados.");
                return;
            }
            System.out.println("\nID | Nombre completo | DNI | Edad | Carrera | Ciclo | Estado");
            System.out.println("---------------------------------------------------------------------");
            for (Student s : students) {
                System.out.printf(
                        "%d | %s %s %s | %s | %d | %s | %d | %s%n",
                        s.getId(),
                        s.getFirstName(),
                        s.getLastName(),
                        s.getMiddleName(),
                        s.getDocumentNumber(),
                        s.getAge(),
                        s.getMajor(),
                        s.getCycle(),
                        s.getStatus()
                );
            }
        } catch (SQLException e) {
            System.out.println("Error al listar estudiantes: " + e.getMessage());
        }
    }

    private void createStudent(Scanner scanner) {
        try {
            Student student = readStudentData(scanner);
            studentDAO.create(student);
            System.out.println("Estudiante registrado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al registrar estudiante: " + e.getMessage());
        }
    }

    private void updateStudent(Scanner scanner) {
        System.out.print("Ingrese el ID del estudiante a actualizar: ");
        int id = readInt(scanner);
        try {
            Student existing = studentDAO.findById(id);
            if (existing == null) {
                System.out.println("No existe un estudiante con ese ID.");
                return;
            }
            Student student = readStudentData(scanner);
            student.setId(id);
            studentDAO.update(student);
            System.out.println("Estudiante actualizado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al actualizar estudiante: " + e.getMessage());
        }
    }

    private void deleteStudent(Scanner scanner) {
        System.out.print("Ingrese el ID del estudiante a eliminar: ");
        int id = readInt(scanner);
        try {
            studentDAO.delete(id);
            System.out.println("Estudiante eliminado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar estudiante: " + e.getMessage());
        }
    }

    private void findStudent(Scanner scanner) {
        System.out.print("Ingrese el ID del estudiante: ");
        int id = readInt(scanner);
        try {
            Student s = studentDAO.findById(id);
            if (s == null) {
                System.out.println("No existe un estudiante con ese ID.");
                return;
            }
            System.out.println("\nID: " + s.getId());
            System.out.println("Nombre: " + s.getFirstName());
            System.out.println("Apellido paterno: " + s.getLastName());
            System.out.println("Apellido materno: " + s.getMiddleName());
            System.out.println("DNI: " + s.getDocumentNumber());
            System.out.println("Correo: " + s.getEmail());
            System.out.println("Teléfono: " + s.getPhone());
            System.out.println("Edad: " + s.getAge());
            System.out.println("Carrera: " + s.getMajor());
            System.out.println("Ciclo: " + s.getCycle());
            System.out.println("Estado: " + s.getStatus());
        } catch (SQLException e) {
            System.out.println("Error al buscar estudiante: " + e.getMessage());
        }
    }

    private Student readStudentData(Scanner scanner) {
        Student student = new Student();

        System.out.print("Nombre: ");
        student.setFirstName(readNonEmptyText(scanner));

        System.out.print("Apellido paterno: ");
        student.setLastName(readNonEmptyText(scanner));

        System.out.print("Apellido materno: ");
        student.setMiddleName(readNonEmptyText(scanner));

        student.setDocumentNumber(readDocumentNumber(scanner));

        System.out.print("Dirección: ");
        student.setAddress(scanner.nextLine().trim());

        student.setEmail(readEmail(scanner));

        student.setPhone(readPhone(scanner));

        LocalDate birthDate = readBirthDate(scanner);
        student.setBirthDate(birthDate);
        int age = Period.between(birthDate, LocalDate.now()).getYears();
        student.setAge(age);

        student.setGender(readGender(scanner));

        System.out.print("Distrito: ");
        student.setDistrict(readNonEmptyText(scanner));

        System.out.print("Carrera: ");
        student.setMajor(readNonEmptyText(scanner));

        student.setCycle(readCycle(scanner));

        student.setStatus(readStatus(scanner));

        return student;
    }

    private int readInt(Scanner scanner) {
        while (true) {
            String line = scanner.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (NumberFormatException e) {
                System.out.print("Número inválido, intente de nuevo: ");
            }
        }
    }

    private String readNonEmptyText(Scanner scanner) {
        while (true) {
            String text = scanner.nextLine().trim();
            if (!text.isEmpty()) {
                return text;
            }
            System.out.print("Este campo es obligatorio, intente de nuevo: ");
        }
    }

    private String readDocumentNumber(Scanner scanner) {
        Pattern pattern = Pattern.compile("^[0-9]{8}$");
        while (true) {
            System.out.print("DNI (8 dígitos): ");
            String value = scanner.nextLine().trim();
            if (pattern.matcher(value).matches()) {
                return value;
            }
            System.out.println("DNI inválido. Debe tener exactamente 8 dígitos numéricos.");
        }
    }

    private String readEmail(Scanner scanner) {
        while (true) {
            System.out.print("Correo (ENTER si no tiene): ");
            String email = scanner.nextLine().trim();
            if (email.isEmpty()) {
                return null;
            }
            if (email.contains("@") && email.contains(".") && email.length() >= 5) {
                return email;
            }
            System.out.println("Correo inválido. Debe contener '@' y '.'.");
        }
    }

    private String readPhone(Scanner scanner) {
        Pattern pattern = Pattern.compile("^[0-9]{9}$");
        while (true) {
            System.out.print("Teléfono (9 dígitos): ");
            String phone = scanner.nextLine().trim();
            if (pattern.matcher(phone).matches()) {
                return phone;
            }
            System.out.println("Teléfono inválido. Debe tener exactamente 9 dígitos numéricos.");
        }
    }

    private LocalDate readBirthDate(Scanner scanner) {
        while (true) {
            System.out.print("Fecha de nacimiento (yyyy-MM-dd): ");
            String input = scanner.nextLine().trim();
            try {
                LocalDate date = LocalDate.parse(input);
                int age = Period.between(date, LocalDate.now()).getYears();
                if (age < 16) {
                    System.out.println("El estudiante debe tener al menos 16 años.");
                    continue;
                }
                if (age <= 0 || age > 99) {
                    System.out.println("Edad inválida.");
                    continue;
                }
                return date;
            } catch (DateTimeParseException e) {
                System.out.println("Formato de fecha inválido.");
            }
        }
    }

    private String readGender(Scanner scanner) {
        while (true) {
            System.out.print("Sexo (M/F): ");
            String gender = scanner.nextLine().trim().toUpperCase();
            if (gender.equals("M") || gender.equals("F")) {
                return gender;
            }
            System.out.println("Sexo inválido.");
        }
    }

    private int readCycle(Scanner scanner) {
        while (true) {
            System.out.print("Ciclo: ");
            int cycle = readInt(scanner);
            if (cycle >= 1 && cycle <= 20) {
                return cycle;
            }
            System.out.println("Ciclo inválido. Debe estar entre 1 y 20.");
        }
    }

    private String readStatus(Scanner scanner) {
        while (true) {
            System.out.print("Estado (activo/inactivo, ENTER=activo): ");
            String status = scanner.nextLine().trim().toLowerCase();
            if (status.isEmpty()) {
                return "activo";
            }
            if (status.equals("activo") || status.equals("inactivo")) {
                return status;
            }
            System.out.println("Estado inválido.");
        }
    }
}
