package Controller;

import dao.ProfessorDAO;
import model.Professor;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

public class ProfessorController {

    private final ProfessorDAO professorDAO = new ProfessorDAO();

    public void showMenu(Scanner scanner) {
        Map<Integer, Runnable> actions = new HashMap<>();
        actions.put(1, () -> listProfessors());
        actions.put(2, () -> createProfessor(scanner));
        actions.put(3, () -> updateProfessor(scanner));
        actions.put(4, () -> deleteProfessor(scanner));
        actions.put(5, () -> findProfessor(scanner));

        int option;
        do {
            System.out.println("\n--- GESTIONAR PROFESORES ---");
            System.out.println("1. Listar profesores");
            System.out.println("2. Registrar profesor");
            System.out.println("3. Actualizar profesor");
            System.out.println("4. Eliminar profesor");
            System.out.println("5. Buscar profesor por ID");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            option = readInt(scanner);
            if (option == 0) {
                System.out.println("Volviendo al menú principal...");
            } else {
                Runnable action = actions.get(option);
                if (action != null) {
                    action.run();
                } else {
                    System.out.println("Opción inválida.");
                }
            }
        } while (option != 0);
    }

    private void listProfessors() {
        try {
            List<Professor> list = professorDAO.findAll();
            if (list.isEmpty()) {
                System.out.println("No hay profesores registrados.");
                return;
            }
            System.out.println("\nID | Nombre completo | DNI | Especialidad | Horas dictadas");
            System.out.println("---------------------------------------------------------------------");
            for (Professor p : list) {
                System.out.printf(
                        "%d | %s %s %s | %s | %s | %d%n",
                        p.getId(),
                        p.getFirstName(),
                        p.getLastName(),
                        p.getMiddleName(),
                        p.getDocumentNumber(),
                        p.getSpecialty(),
                        p.getTaughtHours()
                );
            }
        } catch (SQLException e) {
            System.out.println("Error al listar profesores: " + e.getMessage());
        }
    }

    private void createProfessor(Scanner scanner) {
        try {
            Professor professor = readProfessorData(scanner);
            professorDAO.create(professor);
            System.out.println("Profesor registrado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al registrar profesor: " + e.getMessage());
        }
    }

    private void updateProfessor(Scanner scanner) {
        System.out.print("Ingrese el ID del profesor a actualizar: ");
        int id = readInt(scanner);
        try {
            Professor existing = professorDAO.findById(id);
            if (existing == null) {
                System.out.println("No existe un profesor con ese ID.");
                return;
            }
            Professor professor = readProfessorData(scanner);
            professor.setId(id);
            professorDAO.update(professor);
            System.out.println("Profesor actualizado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al actualizar profesor: " + e.getMessage());
        }
    }

    private void deleteProfessor(Scanner scanner) {
        System.out.print("Ingrese el ID del profesor a eliminar: ");
        int id = readInt(scanner);
        try {
            professorDAO.delete(id);
            System.out.println("Profesor eliminado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar profesor: " + e.getMessage());
        }
    }

    private void findProfessor(Scanner scanner) {
        System.out.print("Ingrese el ID del profesor: ");
        int id = readInt(scanner);
        try {
            Professor p = professorDAO.findById(id);
            if (p == null) {
                System.out.println("No existe un profesor con ese ID.");
                return;
            }
            System.out.println("\nID: " + p.getId());
            System.out.println("Nombre: " + p.getFirstName());
            System.out.println("Apellido paterno: " + p.getLastName());
            System.out.println("Apellido materno: " + p.getMiddleName());
            System.out.println("DNI: " + p.getDocumentNumber());
            System.out.println("Especialidad: " + p.getSpecialty());
            System.out.println("Correo: " + p.getEmail());
            System.out.println("Teléfono: " + p.getPhone());
            System.out.println("Horas dictadas: " + p.getTaughtHours());
        } catch (SQLException e) {
            System.out.println("Error al buscar profesor: " + e.getMessage());
        }
    }

    private Professor readProfessorData(Scanner scanner) {
        Professor professor = new Professor();

        System.out.print("Nombre: ");
        professor.setFirstName(readNonEmptyText(scanner));

        System.out.print("Apellido paterno: ");
        professor.setLastName(readNonEmptyText(scanner));

        System.out.print("Apellido materno: ");
        professor.setMiddleName(readNonEmptyText(scanner));

        professor.setDocumentNumber(readDocumentNumber(scanner));

        System.out.print("Especialidad: ");
        professor.setSpecialty(readNonEmptyText(scanner));

        professor.setEmail(readEmail(scanner));

        professor.setPhone(readPhone(scanner));

        professor.setTaughtHours(readNonNegativeInt(scanner, "Horas dictadas: "));

        return professor;
    }

    private int readInt(Scanner scanner) {
        while (true) {
            String line = scanner.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (NumberFormatException e) {
                System.out.print("Número inválido, intente de nuevo: ");
            }
        }
    }

    private int readNonNegativeInt(Scanner scanner, String label) {
        while (true) {
            System.out.print(label);
            int value = readInt(scanner);
            if (value >= 0) {
                return value;
            }
            System.out.println("El valor no puede ser negativo.");
        }
    }

    private String readNonEmptyText(Scanner scanner) {
        while (true) {
            String text = scanner.nextLine().trim();
            if (!text.isEmpty()) {
                return text;
            }
            System.out.print("Este campo es obligatorio, intente de nuevo: ");
        }
    }

    private String readDocumentNumber(Scanner scanner) {
        Pattern pattern = Pattern.compile("^[0-9]{8}$");
        while (true) {
            System.out.print("DNI (8 dígitos): ");
            String value = scanner.nextLine().trim();
            if (pattern.matcher(value).matches()) {
                return value;
            }
            System.out.println("DNI inválido. Debe tener exactamente 8 dígitos numéricos.");
        }
    }

    private String readEmail(Scanner scanner) {
        while (true) {
            System.out.print("Correo (ENTER si no tiene): ");
            String email = scanner.nextLine().trim();
            if (email.isEmpty()) {
                return null;
            }
            if (email.contains("@") && email.contains(".") && email.length() >= 5) {
                return email;
            }
            System.out.println("Correo inválido. Debe contener '@' y '.'.");
        }
    }

    private String readPhone(Scanner scanner) {
        Pattern pattern = Pattern.compile("^[0-9]{9}$");
        while (true) {
            System.out.print("Teléfono (9 dígitos): ");
            String phone = scanner.nextLine().trim();
            if (pattern.matcher(phone).matches()) {
                return phone;
            }
            System.out.println("Teléfono inválido. Debe tener exactamente 9 dígitos numéricos.");
        }
    }
}
