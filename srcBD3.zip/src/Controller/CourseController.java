package Controller;

import dao.CourseDAO;
import model.Course;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CourseController {

    private final CourseDAO courseDAO = new CourseDAO();

    public void showMenu(Scanner scanner) {
        Map<Integer, Runnable> actions = new HashMap<>();
        actions.put(1, () -> listCourses());
        actions.put(2, () -> createCourse(scanner));
        actions.put(3, () -> updateCourse(scanner));
        actions.put(4, () -> deleteCourse(scanner));
        actions.put(5, () -> findCourse(scanner));

        int option;
        do {
            System.out.println("\n--- GESTIONAR CURSOS ---");
            System.out.println("1. Listar cursos");
            System.out.println("2. Registrar curso");
            System.out.println("3. Actualizar curso");
            System.out.println("4. Eliminar curso");
            System.out.println("5. Buscar curso por ID");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            option = readInt(scanner);
            if (option == 0) {
                System.out.println("Volviendo al menú principal...");
            } else {
                Runnable action = actions.get(option);
                if (action != null) {
                    action.run();
                } else {
                    System.out.println("Opción inválida.");
                }
            }
        } while (option != 0);
    }

    private void listCourses() {
        try {
            List<Course> list = courseDAO.findAll();
            if (list.isEmpty()) {
                System.out.println("No hay cursos registrados.");
                return;
            }
            System.out.println("\nID | Nombre | Créditos | Semestre");
            System.out.println("------------------------------------------");
            for (Course c : list) {
                System.out.printf(
                        "%d | %s | %d | %d%n",
                        c.getId(),
                        c.getName(),
                        c.getCredits(),
                        c.getSemester()
                );
            }
        } catch (SQLException e) {
            System.out.println("Error al listar cursos: " + e.getMessage());
        }
    }

    private void createCourse(Scanner scanner) {
        try {
            Course course = readCourseData(scanner);
            courseDAO.create(course);
            System.out.println("Curso registrado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al registrar curso: " + e.getMessage());
        }
    }

    private void updateCourse(Scanner scanner) {
        System.out.print("Ingrese el ID del curso a actualizar: ");
        int id = readInt(scanner);
        try {
            Course existing = courseDAO.findById(id);
            if (existing == null) {
                System.out.println("No existe un curso con ese ID.");
                return;
            }
            Course course = readCourseData(scanner);
            course.setId(id);
            courseDAO.update(course);
            System.out.println("Curso actualizado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al actualizar curso: " + e.getMessage());
        }
    }

    private void deleteCourse(Scanner scanner) {
        System.out.print("Ingrese el ID del curso a eliminar: ");
        int id = readInt(scanner);
        try {
            courseDAO.delete(id);
            System.out.println("Curso eliminado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar curso: " + e.getMessage());
        }
    }

    private void findCourse(Scanner scanner) {
        System.out.print("Ingrese el ID del curso: ");
        int id = readInt(scanner);
        try {
            Course c = courseDAO.findById(id);
            if (c == null) {
                System.out.println("No existe un curso con ese ID.");
                return;
            }
            System.out.println("\nID: " + c.getId());
            System.out.println("Nombre: " + c.getName());
            System.out.println("Créditos: " + c.getCredits());
            System.out.println("Semestre: " + c.getSemester());
        } catch (SQLException e) {
            System.out.println("Error al buscar curso: " + e.getMessage());
        }
    }

    private Course readCourseData(Scanner scanner) {
        Course course = new Course();

        System.out.print("Nombre del curso: ");
        course.setName(readNonEmptyText(scanner));

        course.setCredits(readPositiveInt(scanner, "Créditos (1-20): ", 1, 20));
        course.setSemester(readPositiveInt(scanner, "Semestre (1-12): ", 1, 12));

        return course;
    }

    private int readInt(Scanner scanner) {
        while (true) {
            String line = scanner.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (NumberFormatException e) {
                System.out.print("Número inválido, intente de nuevo: ");
            }
        }
    }

    private int readPositiveInt(Scanner scanner, String label, int min, int max) {
        while (true) {
            System.out.print(label);
            int value = readInt(scanner);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.println("Valor inválido. Debe estar entre " + min + " y " + max + ".");
        }
    }

    private String readNonEmptyText(Scanner scanner) {
        while (true) {
            String text = scanner.nextLine().trim();
            if (!text.isEmpty()) {
                return text;
            }
            System.out.print("Este campo es obligatorio, intente de nuevo: ");
        }
    }
}
