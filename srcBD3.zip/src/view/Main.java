package view;

import Controller.CourseController;
import Controller.ProfessorController;
import Controller.StudentController;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentController studentController = new StudentController();
        ProfessorController professorController = new ProfessorController();
        CourseController courseController = new CourseController();

        int option;
        do {
            System.out.println("\n=== SISTEMA ACADEMICO ===");
            System.out.println("1. Gestionar Estudiantes");
            System.out.println("2. Gestionar Profesores");
            System.out.println("3. Gestionar Cursos");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");

            String input = scanner.nextLine();
            try {
                option = Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                option = -1;
            }

            switch (option) {
                case 1 -> studentController.showMenu(scanner);
                case 2 -> professorController.showMenu(scanner);
                case 3 -> courseController.showMenu(scanner);
                case 0 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }

        } while (option != 0);

        scanner.close();
    }
}
