package app;

import Controller.StudentController;

public class Main {
    public static void main(String[] args) {
        new StudentController().start();
    }
}
