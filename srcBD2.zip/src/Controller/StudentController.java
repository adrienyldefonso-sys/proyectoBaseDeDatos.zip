package Controller;

import model.Student;
import model.StudentDAO;
import View.MenuView;

public class StudentController {
    private MenuView view = new MenuView();
    private StudentDAO dao = new StudentDAO();

    public void start() {
        while (true) {
            int op = view.showMenu();
            switch (op) {
                case 1 -> add();
                case 2 -> list();
                case 3 -> search();
                case 4 -> update();
                case 5 -> delete();
                case 6 -> System.exit(0);
            }
        }
    }

    public void add() {
        var sc = view.getScanner();
        System.out.print("Código: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Apellidos: ");
        String ln = sc.nextLine();
        System.out.print("Nombres: ");
        String fn = sc.nextLine();
        System.out.print("DNI: ");
        String dni = sc.nextLine();
        System.out.print("Dirección: ");
        String address = sc.nextLine();
        System.out.print("Fecha de nacimiento (YYYY-MM-DD): ");
        String bd = sc.nextLine();
        System.out.print("Nota: ");
        double grade = sc.nextDouble();
        try {
            dao.insert(new Student(id, ln, fn, dni, address, bd, grade));
        } catch (Exception e) {
            System.out.println("Ocurrió un error");
        }
    }

    public void list() {
        try {
            for (Student s : dao.listAll()) {
                System.out.println(
                        s.getId() + " | " +
                                s.getLastName() + ", " +
                                s.getFirstName() + " | DNI: " +
                                s.getDni() + " | Dirección: " +
                                s.getAddress() + " | Nacimiento: " +
                                s.getBirthDate() + " | Nota: " +
                                s.getGrade()
                );
            }
        } catch (Exception e) {
            System.out.println("Ocurrió un error");
        }
    }

    public void search() {
        var sc = view.getScanner();
        System.out.print("DNI a buscar: ");
        sc.nextLine();
        String dni = sc.nextLine();
        try {
            Student s = dao.searchByDni(dni);
            if (s != null) {
                System.out.println(
                        s.getId() + " | " +
                                s.getLastName() + ", " +
                                s.getFirstName() + " | Dirección: " +
                                s.getAddress() + " | Nacimiento: " +
                                s.getBirthDate() + " | Nota: " +
                                s.getGrade()
                );
            }
        } catch (Exception e) {
            System.out.println("Ocurrió un error");
        }
    }

    public void update() {
        var sc = view.getScanner();
        System.out.print("DNI del estudiante a actualizar: ");
        sc.nextLine();
        String dni = sc.nextLine();
        System.out.print("Nuevo apellido: ");
        String ln = sc.nextLine();
        System.out.print("Nuevo nombre: ");
        String fn = sc.nextLine();
        System.out.print("Nueva dirección: ");
        String address = sc.nextLine();
        System.out.print("Nueva fecha de nacimiento (YYYY-MM-DD): ");
        String bd = sc.nextLine();
        System.out.print("Nueva nota: ");
        double grade = sc.nextDouble();
        try {
            dao.update(new Student(0, ln, fn, dni, address, bd, grade));
        } catch (Exception e) {
            System.out.println("Ocurrió un error");
        }
    }

    public void delete() {
        var sc = view.getScanner();
        System.out.print("DNI del estudiante a eliminar: ");
        sc.nextLine();
        String dni = sc.nextLine();
        try {
            dao.delete(dni);
        } catch (Exception e) {
            System.out.println("Ocurrió un error");
        }
    }
}
