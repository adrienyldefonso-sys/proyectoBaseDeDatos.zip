package View;

import java.util.Scanner;

public class MenuView {
    private Scanner sc = new Scanner(System.in);

    public int showMenu() {
        System.out.println("===== MENÚ PRINCIPAL =====");
        System.out.println("1. Agregar estudiante");
        System.out.println("2. Mostrar estudiantes");
        System.out.println("3. Buscar por DNI");
        System.out.println("4. Actualizar estudiante");
        System.out.println("5. Eliminar estudiante");
        System.out.println("6. Salir");
        System.out.print("Elija una opción: ");
        return sc.nextInt();
    }

    public Scanner getScanner() {
        return sc;
    }
}
