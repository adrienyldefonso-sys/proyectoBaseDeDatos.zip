package model;

public class Student {
    private int id;
    private String lastName;
    private String firstName;
    private String dni;
    private String address;
    private String birthDate;
    private double grade;

    public Student(int id, String lastName, String firstName, String dni, String address, String birthDate, double grade) {
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.dni = dni;
        this.address = address;
        this.birthDate = birthDate;
        this.grade = grade;
    }

    public int getId() { return id; }
    public String getLastName() { return lastName; }
    public String getFirstName() { return firstName; }
    public String getDni() { return dni; }
    public String getAddress() { return address; }
    public String getBirthDate() { return birthDate; }
    public double getGrade() { return grade; }
}
