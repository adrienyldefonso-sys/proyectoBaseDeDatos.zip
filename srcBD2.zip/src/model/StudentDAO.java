package model;

import java.sql.*;
import java.util.ArrayList;

public class StudentDAO {
    private final String url = "jdbc:mysql://localhost:3306/studentsdb";
    private final String user = "root";
    private final String pass = "";

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }

    public void insert(Student s) throws SQLException {
        Connection cn = connect();
        cn.setAutoCommit(false);
        PreparedStatement ps = cn.prepareStatement("INSERT INTO students VALUES (?,?,?,?,?,?,?)");
        ps.setInt(1, s.getId());
        ps.setString(2, s.getLastName());
        ps.setString(3, s.getFirstName());
        ps.setString(4, s.getDni());
        ps.setString(5, s.getAddress());
        ps.setString(6, s.getBirthDate());
        ps.setDouble(7, s.getGrade());
        ps.executeUpdate();
        cn.commit();
        cn.close();
    }

    public ArrayList<Student> listAll() throws SQLException {
        Connection cn = connect();
        PreparedStatement ps = cn.prepareStatement("SELECT * FROM students");
        ResultSet rs = ps.executeQuery();
        ArrayList<Student> list = new ArrayList<>();
        while (rs.next()) {
            list.add(new Student(
                    rs.getInt("id"),
                    rs.getString("last_name"),
                    rs.getString("first_name"),
                    rs.getString("dni"),
                    rs.getString("address"),
                    rs.getString("birth_date"),
                    rs.getDouble("grade")
            ));
        }
        cn.close();
        return list;
    }

    public Student searchByDni(String dni) throws SQLException {
        Connection cn = connect();
        PreparedStatement ps = cn.prepareStatement("SELECT * FROM students WHERE dni=?");
        ps.setString(1, dni);
        ResultSet rs = ps.executeQuery();
        Student s = null;
        if (rs.next()) {
            s = new Student(
                    rs.getInt("id"),
                    rs.getString("last_name"),
                    rs.getString("first_name"),
                    rs.getString("dni"),
                    rs.getString("address"),
                    rs.getString("birth_date"),
                    rs.getDouble("grade")
            );
        }
        cn.close();
        return s;
    }

    public void update(Student s) throws SQLException {
        Connection cn = connect();
        PreparedStatement ps = cn.prepareStatement(
                "UPDATE students SET last_name=?, first_name=?, address=?, birth_date=?, grade=? WHERE dni=?"
        );
        ps.setString(1, s.getLastName());
        ps.setString(2, s.getFirstName());
        ps.setString(3, s.getAddress());
        ps.setString(4, s.getBirthDate());
        ps.setDouble(5, s.getGrade());
        ps.setString(6, s.getDni());
        ps.executeUpdate();
        cn.close();
    }

    public void delete(String dni) throws SQLException {
        Connection cn = connect();
        PreparedStatement ps = cn.prepareStatement("DELETE FROM students WHERE dni=?");
        ps.setString(1, dni);
        ps.executeUpdate();
        cn.close();
    }
}
