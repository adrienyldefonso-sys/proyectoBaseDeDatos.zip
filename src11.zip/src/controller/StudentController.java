package controller;

import model.Student;
import model.StudentDAO;
import java.util.ArrayList;

public class StudentController {
    private final StudentDAO dao = new StudentDAO();

    public void registrar(Student s) {
        dao.insertar(s);
    }

    public ArrayList<Student> obtenerTodos() {
        return dao.listar();
    }

    public void actualizar(Student s) {
        dao.actualizar(s);
    }

    public Student buscarPorDni(String dni) {
        return dao.buscarPorDni(dni);
    }

    public void eliminar(int codigo) {
        dao.eliminar(codigo);
    }
}
