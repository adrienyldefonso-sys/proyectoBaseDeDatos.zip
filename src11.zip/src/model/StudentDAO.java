package model;

import java.sql.*;
import java.util.ArrayList;

public class StudentDAO {
    public void insertar(Student s) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            try {
                PreparedStatement ps = conn.prepareStatement("INSERT INTO alumnos VALUES (?, ?, ?, ?, ?)");
                ps.setInt(1, s.getCodigo());
                ps.setString(2, s.getApellidos());
                ps.setString(3, s.getNombres());
                ps.setString(4, s.getDni());
                ps.setString(5, s.getDireccion());
                ps.executeUpdate();
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public ArrayList<Student> listar() {
        ArrayList<Student> lista = new ArrayList<>();
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            try {
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT * FROM alumnos");
                while (rs.next()) {
                    lista.add(new Student(
                            rs.getInt("codigo"),
                            rs.getString("apellidos"),
                            rs.getString("nombres"),
                            rs.getString("dni"),
                            rs.getString("direccion")));
                }
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        return lista;
    }

    public void actualizar(Student s) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            try {
                PreparedStatement ps = conn.prepareStatement(
                        "UPDATE alumnos SET apellidos=?, nombres=?, dni=?, direccion=? WHERE codigo=?");
                ps.setString(1, s.getApellidos());
                ps.setString(2, s.getNombres());
                ps.setString(3, s.getDni());
                ps.setString(4, s.getDireccion());
                ps.setInt(5, s.getCodigo());
                ps.executeUpdate();
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public Student buscarPorDni(String dni) {
        Connection conn = DatabaseConnection.getConnection();
        Student s = null;
        if (conn != null) {
            try {
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM alumnos WHERE dni=?");
                ps.setString(1, dni);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    s = new Student(
                            rs.getInt("codigo"),
                            rs.getString("apellidos"),
                            rs.getString("nombres"),
                            rs.getString("dni"),
                            rs.getString("direccion"));
                }
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        return s;
    }

    public void eliminar(int codigo) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            try {
                PreparedStatement ps = conn.prepareStatement("DELETE FROM alumnos WHERE codigo=?");
                ps.setInt(1, codigo);
                ps.executeUpdate();
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
