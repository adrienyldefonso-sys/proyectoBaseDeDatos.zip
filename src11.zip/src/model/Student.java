package model;

public class Student {
    private int codigo;
    private String apellidos;
    private String nombres;
    private String dni;
    private String direccion;

    public Student(int codigo, String apellidos, String nombres, String dni, String direccion) {
        this.codigo = codigo;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.dni = dni;
        this.direccion = direccion;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public String getDni() {
        return dni;
    }

    public String getDireccion() {
        return direccion;
    }
}
