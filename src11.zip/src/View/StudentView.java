package View;

import controller.StudentController;
import model.Student;
import java.util.ArrayList;

public class StudentView {
    private final StudentController controller = new StudentController();

    public void registrarAlumno(Student s) {
        controller.registrar(s);
    }

    public void mostrarAlumnos() {
        ArrayList<Student> lista = controller.obtenerTodos();
        System.out.println("\nCódigo | Apellidos | Nombres | DNI | Dirección");
        for (Student s : lista) {
            System.out.println(s.getCodigo() + " | " + s.getApellidos() + " | " + s.getNombres() + " | " + s.getDni() + " | " + s.getDireccion());
        }
    }

    public void actualizarAlumno(Student s) {
        controller.actualizar(s);
    }

    public void buscarPorDni(String dni) {
        Student s = controller.buscarPorDni(dni);
        if (s != null) {
            System.out.println(s.getCodigo() + " | " + s.getApellidos() + " | " + s.getNombres() + " | " + s.getDni() + " | " + s.getDireccion());
        } else {
            System.out.println("No se encontró alumno con ese DNI.");
        }
    }

    public void eliminarAlumno(int codigo) {
        controller.eliminar(codigo);
    }
}
