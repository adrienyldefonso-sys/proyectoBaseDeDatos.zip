package Lab11;

import model.Student;
import View.StudentView;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentView vista = new StudentView();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nGestión de Alumnos:");
            System.out.println("1. Registrar alumno");
            System.out.println("2. Mostrar alumnos");
            System.out.println("3. Actualizar alumno");
            System.out.println("4. Buscar por DNI");
            System.out.println("5. Eliminar alumno");
            System.out.println("6. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Código: ");
                    int codigo = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Apellidos: ");
                    String apellidos = sc.nextLine();
                    System.out.print("Nombres: ");
                    String nombres = sc.nextLine();
                    System.out.print("DNI: ");
                    String dni = sc.nextLine();
                    System.out.print("Dirección: ");
                    String direccion = sc.nextLine();
                    vista.registrarAlumno(new Student(codigo, apellidos, nombres, dni, direccion));
                    break;

                case 2:
                    vista.mostrarAlumnos();
                    break;

                case 3:
                    System.out.print("Código del alumno a actualizar: ");
                    int codigoActualizar = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nuevos apellidos: ");
                    String nuevosApellidos = sc.nextLine();
                    System.out.print("Nuevos nombres: ");
                    String nuevosNombres = sc.nextLine();
                    System.out.print("Nuevo DNI: ");
                    String nuevoDni = sc.nextLine();
                    System.out.print("Nueva dirección: ");
                    String nuevaDireccion = sc.nextLine();
                    vista.actualizarAlumno(new Student(codigoActualizar, nuevosApellidos, nuevosNombres, nuevoDni, nuevaDireccion));
                    break;

                case 4:
                    System.out.print("Ingrese el DNI: ");
                    String buscarDni = sc.nextLine();
                    vista.buscarPorDni(buscarDni);
                    break;

                case 5:
                    System.out.print("Ingrese el código a eliminar: ");
                    int codigoEliminar = sc.nextInt();
                    vista.eliminarAlumno(codigoEliminar);
                    break;

                case 6:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 6);
    }
}
